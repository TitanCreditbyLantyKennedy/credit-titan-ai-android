plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.credittitan.ai"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.credittitan.ai"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.2.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
