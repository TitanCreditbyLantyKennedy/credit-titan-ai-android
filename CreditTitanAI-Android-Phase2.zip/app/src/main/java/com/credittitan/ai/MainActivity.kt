package com.credittitan.ai

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.widget.*

class MainActivity : Activity() {
    private val navy = Color.rgb(9, 19, 43)
    private val blue = Color.rgb(34, 143, 255)
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showPage("Dashboard")
    }

    private fun text(value: String, size: Float = 17f): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(Color.WHITE)
            setPadding(18, 16, 18, 16)
        }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setBackgroundColor(blue)
            setOnClickListener { action() }
        }

    private fun showPage(page: String) {
        val scroll = ScrollView(this).apply { setBackgroundColor(navy) }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 24, 18, 24)
        }
        scroll.addView(content)
        setContentView(scroll)
        content.addView(text("CREDIT TITAN AI", 28f))
        content.addView(text("Creator • Developer • Designer: Lanty Kennedy", 12f))
        content.addView(text("DEMO ONLY • Fictional information", 13f))
        content.addView(text(page, 25f))
        when (page) {
            "Dashboard" -> {
                content.addView(text("Illustrative credit score: 704", 26f))
                content.addView(text("Estimated utilization: 24%\nOn-time payments: 98%\nDemo progress: +18 points"))
            }
            "Report Analyzer" -> {
                content.addView(text("Sample report findings"))
                content.addView(text("• Review account dates and balances\n• Verify personal details\n• Identify potential inaccuracies"))
                content.addView(text("No actual credit report is accessed."))
            }
            "Dispute Center" -> {
                content.addView(text("Dispute assistance checklist"))
                content.addView(text("1. Identify potentially inaccurate information\n2. Collect supporting records\n3. Draft a clear dispute\n4. Review before sending"))
                content.addView(text("No disputes are submitted."))
            }
            "AI Coach" -> {
                content.addView(text("Educational coaching tips"))
                content.addView(text("Pay on time, keep balances manageable, and review your reports for accuracy. This demo does not call an AI service."))
            }
            "Three Bureaus" -> {
                content.addView(text("Experian • Equifax • TransUnion"))
                content.addView(text("Monitoring integration is planned. No live bureau connections."))
            }
            "Progress" -> {
                content.addView(text("Illustrative 3-month journey"))
                content.addView(text("Month 1: 686\nMonth 2: 695\nMonth 3: 704"))
                content.addView(text("All values are fictional."))
            }
        }
        listOf("Dashboard", "Report Analyzer", "Dispute Center", "AI Coach", "Three Bureaus", "Progress").forEach { label ->
            content.addView(button(label) { showPage(label) })
        }
    }
}
