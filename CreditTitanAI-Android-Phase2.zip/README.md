# Credit Titan AI — Android Phase 2

**Creator, Developer, and Designer: Lanty Kennedy**

Native Android demo with fictional credit information, interactive page navigation, report review checklist, dispute assistance, educational coach, three-bureau integration concept, and progress tracking.

**No real credit bureau connections, financial account access, automated AI analysis, or dispute submissions.**

## Build APK from GitHub

Upload the *contents* of this project ZIP to the root of your GitHub repository, preserving folders and the hidden `.github/workflows/android-apk.yml` path. GitHub's web upload interface may not accept folders or ZIP extraction directly. A Git-capable Android app or GitHub Codespaces can be used to unpack and commit the project.

Once the files are committed to `main`, open **Actions → Build Android Demo APK → Run workflow**. After a successful build, download the **CreditTitanAI-Debug-APK** artifact, extract it, and install `app-debug.apk` on your phone. This is a test build, not a Play Store release.
